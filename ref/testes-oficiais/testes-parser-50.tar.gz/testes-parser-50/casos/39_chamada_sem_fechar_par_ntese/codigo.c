int main() { foo(1, 2; }
