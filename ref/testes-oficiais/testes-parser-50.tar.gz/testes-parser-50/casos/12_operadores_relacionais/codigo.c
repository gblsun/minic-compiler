bool ok = 3 <= 4 && 8 != 9;
