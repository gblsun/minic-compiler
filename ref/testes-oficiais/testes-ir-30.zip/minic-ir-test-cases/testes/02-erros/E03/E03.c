int main() {
    int x;
    bool b = true;
    x = b;
    return 0;
}
